﻿namespace _01.Vehicles.Models.Contracts
{
    public interface IRefuel
    {
        public void Refuel(double fuelQuantity);
    }
}
