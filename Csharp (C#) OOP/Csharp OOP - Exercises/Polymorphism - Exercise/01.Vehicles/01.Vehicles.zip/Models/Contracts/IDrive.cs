﻿namespace _01.Vehicles.Models.Contracts
{
    public interface IDrive
    {
        public string Drive(double distance);
    }
}
