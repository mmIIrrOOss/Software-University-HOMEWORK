﻿namespace VaporStore.DataProcessor
{ 
    using Data;
    using System;

    public static class Serializer
    {
        public static string ExportGamesByGenres(VaporStoreDbContext context, string[] genreNames)
        {
            return "TODOO";
        }

        public static string ExportUserPurchasesByType(VaporStoreDbContext context, string purchaseType)
        {
            return "TODOO";
        }
    }
}