﻿using BookShop.Models;

namespace BookShop.Data
{
    using Microsoft.EntityFrameworkCore;

    public class BookShopContext : DbContext
    {
        public BookShopContext()
        {
        }

        public BookShopContext(DbContextOptions options)
            : base(options)
        {
        }

        public DbSet<Author> Authors { get; set; }

        public DbSet<Book> Books { get; set; }

        public DbSet<BookCategory> BookCategories { get; set; }

        public DbSet<Category> Categories { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.
                    UseSqlServer("Server=.;Database=StudentSystem;Integrated Security=True");
            }
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //Author
            modelBuilder.Entity<Author>()
                .Property(x => x.FirstName)
                .IsUnicode(true)
                .IsRequired(false);

            modelBuilder.Entity<Author>()
                .Property(x => x.LastName)
                .IsUnicode(true)
                .IsRequired(true);

            //Book
            modelBuilder.Entity<Book>()
                .Property(x => x.Ttile)
                .IsUnicode(true);

            modelBuilder.Entity<Book>()
                .Property(x => x.Description)
                .IsUnicode(true);

            //Category
            modelBuilder.Entity<Category>()
                .Property(x => x.Name)
                .IsUnicode(true);

            //BookCategory
            modelBuilder.Entity<BookCategory>()
                .HasKey(x => new { x.BookId, x.CategoryId });

            base.OnModelCreating(modelBuilder);
        }


    }
}
