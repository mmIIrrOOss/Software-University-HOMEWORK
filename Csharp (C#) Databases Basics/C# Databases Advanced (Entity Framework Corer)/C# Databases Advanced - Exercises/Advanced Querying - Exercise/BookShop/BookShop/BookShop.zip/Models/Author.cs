﻿namespace BookShop.Models
{
    using System.ComponentModel.DataAnnotations;

    public class Author
    {
        public int AuthorId { get; set; }

        [MaxLength(50)]
        public string FirstName  { get; set; }

        [MaxLength(50)]
        public string LastName  { get; set; }
    }
}
