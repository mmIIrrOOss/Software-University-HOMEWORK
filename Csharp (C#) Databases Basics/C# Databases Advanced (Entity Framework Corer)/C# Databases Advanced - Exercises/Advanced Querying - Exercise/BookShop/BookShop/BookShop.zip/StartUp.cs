﻿namespace BookShop
{
    using System;

    using BookShop.Data;

    class StartUp
    {
        static void Main(string[] args)
        {
            var context = new BookShopContext();
            context.Database.EnsureCreated();
            //context.Database.EnsureDeleted();
        }
    }
}
