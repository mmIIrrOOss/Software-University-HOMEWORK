﻿namespace P01_StudentSystem.Data.Models.enums
{
    public enum ResourceType
    {
        Video,
        Presentation,
        Document,
        Other
    }
}
