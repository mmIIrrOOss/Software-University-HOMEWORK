﻿namespace WildFarm
{
	public interface IProducingSoundForFood
	{

		public abstract string ProduceSoundSForFood();

	}
}