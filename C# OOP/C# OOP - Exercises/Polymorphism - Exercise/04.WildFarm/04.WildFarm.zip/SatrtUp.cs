﻿
namespace WildFarm
{
	using System;
	public class SatrtUp
	{
		public static void Main()
		{
			Engine engine = new Engine();
			engine.Run();
		}
	}
}
