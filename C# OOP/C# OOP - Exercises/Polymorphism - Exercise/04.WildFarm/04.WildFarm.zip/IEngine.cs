﻿namespace WildFarm
{
	public interface IEngine
	{
		void Run();
	}
}