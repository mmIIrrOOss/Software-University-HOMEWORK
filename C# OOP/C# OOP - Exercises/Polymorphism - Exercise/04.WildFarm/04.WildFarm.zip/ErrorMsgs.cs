﻿
namespace WildFarm
{
	using System;
	using System.Collections.Generic;
	public class ErrorMsgs
	{
		public const string InvalidTypeMsg = "Invalid Type!";
	}
}
