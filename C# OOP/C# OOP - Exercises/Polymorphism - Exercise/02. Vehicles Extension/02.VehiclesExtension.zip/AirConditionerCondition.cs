﻿namespace VehiclesExtension
{
    public enum AirConditionerCondition
    {
        Off,
        On
    }
}