﻿

namespace Cars
{
	
	public interface IElectircCar
	{
		public int Batery { get; set; }

	}
}
