﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ManufacturingPhones
{
	public interface ICallable
	{
		public string Call(string phoneNumber);
	}
}
