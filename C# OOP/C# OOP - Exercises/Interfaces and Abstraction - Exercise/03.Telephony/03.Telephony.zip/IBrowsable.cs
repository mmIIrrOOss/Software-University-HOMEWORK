﻿

namespace ManufacturingPhones
{
	public interface IBrowsable
	{
		public string Browse(string site);
	}
}

