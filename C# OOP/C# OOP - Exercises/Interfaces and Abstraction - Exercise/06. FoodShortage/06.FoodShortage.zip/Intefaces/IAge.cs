﻿
namespace FoodShortage
{
	public interface IAge
	{
		public int Age { get; }
	}
}
