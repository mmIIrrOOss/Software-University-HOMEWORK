﻿

namespace FoodShortage
{
	public interface IBirthdatetable
	{
		public string Birthdate { get;  }
	}
}
