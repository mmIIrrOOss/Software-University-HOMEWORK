﻿

namespace BirthdayCelebrations
{
	public interface IName
	{
		public string Name { get;  }
	}
}
