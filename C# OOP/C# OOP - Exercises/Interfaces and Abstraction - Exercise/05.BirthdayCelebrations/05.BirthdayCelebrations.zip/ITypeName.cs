﻿

namespace BirthdayCelebrations
{
	
	public interface ITypeName
	{
		public string TypeName { get; }
	}
}
