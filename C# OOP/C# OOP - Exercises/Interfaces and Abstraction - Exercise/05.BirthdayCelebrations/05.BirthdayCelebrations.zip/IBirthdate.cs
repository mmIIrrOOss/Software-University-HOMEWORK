﻿

namespace BirthdayCelebrations
{
	public interface IBirthdatetable
	{
		public string Birthdate { get;  }
	}
}
