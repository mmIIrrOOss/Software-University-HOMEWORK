﻿

namespace MilitaryElite
{
    public enum MissionState
    {
        inProgress,
        Finished
    }
}
