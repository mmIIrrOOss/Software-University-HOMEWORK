﻿namespace MilitaryElite
{
	public interface IPrivate 
	{
		public decimal Salary { get; }
	}
}