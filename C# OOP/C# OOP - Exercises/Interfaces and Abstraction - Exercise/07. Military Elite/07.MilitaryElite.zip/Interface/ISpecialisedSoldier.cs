﻿namespace MilitaryElite
{
	public interface ISpecialisedSoldier 
	{
		 public Corps Corp { get; }
	}
}