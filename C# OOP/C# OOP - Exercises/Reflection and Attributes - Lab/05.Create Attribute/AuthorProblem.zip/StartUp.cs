﻿namespace AuthorProblem
{
    using Models;

    [Author("Miro")]
    public class StartUp
    {
        [Author("mmiirrooss")]
        static void Main(string[] args)
        {

        }
    }
}
