﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FootballTeamGenerator
{
    public interface IOverallSkillLevelOfPlayer
    {
        public int OverallSkillLevelOfPlayer();
    }
}
